public class Main {
    public static void main(String[] args){
        System.out.println(suma(1,2,3));
        Coche Micoche= new Coche();
        Micoche.Sumarpuerta();
        Micoche.Sumarpuerta();
        Micoche.Sumarpuerta();

        System.out.println(Micoche.Puertas);

    }

    public static int suma(int a, int b, int c){
        return a+b+c;
    }
}
class Coche {
    public int Puertas;
    public void Sumarpuerta(){
        this.Puertas++;
    }
}